/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bear extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("bear-a", "./Bear/costumes/bear-a.svg", { x: 100, y: 90 }),
      new Costume("bear jumping", "./Bear/costumes/bear jumping.svg", {
        x: 206.55557250976568,
        y: 83.1
      }),
      new Costume("bear-b", "./Bear/costumes/bear-b.svg", {
        x: 94,
        y: 190.66666666666666
      }),
      new Costume("bleeding", "./Bear/costumes/bleeding.svg", {
        x: 320.8055725097657,
        y: 8.30917232615684
      })
    ];

    this.sounds = [new Sound("pop", "./Bear/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = true;
    this.costume = "bear-a";
    this.goto(250, -185);
    this.size = 40;
    this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
    this.direction = -90;
  }

  *whenGreenFlagClicked2() {
    yield* this.wait(9.2);
    this.costume = "bear jumping";
    yield* this.glide(2, 75, -98);
    this.costume = "bear-b";
    this.goto(16, -99);
  }

  *whenGreenFlagClicked3() {
    yield* this.wait(13.2);
    this.costume = "bleeding";
  }

  *whenGreenFlagClicked4() {
    yield* this.wait(19);
    this.visible = false;
  }
}
