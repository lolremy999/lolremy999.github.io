/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class YipSuGif extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("smile", "./YipSuGif/costumes/smile.svg", {
        x: 17.805585000000008,
        y: 41.67134685188006
      }),
      new Costume("walking", "./YipSuGif/costumes/walking.svg", {
        x: 23.06230182857817,
        y: 41.671338703760114
      }),
      new Costume("cookie", "./YipSuGif/costumes/cookie.svg", {
        x: 17.805575000000005,
        y: 41.671341851880044
      }),
      new Costume("suprised", "./YipSuGif/costumes/suprised.svg", {
        x: 17.805574999999976,
        y: 41.67134685188006
      }),
      new Costume("mad", "./YipSuGif/costumes/mad.svg", {
        x: 17.805574999999976,
        y: 41.67134685188009
      }),
      new Costume("punch", "./YipSuGif/costumes/punch.svg", {
        x: 17.805565,
        y: 41.67134685188009
      })
    ];

    this.sounds = [
      new Sound("Snow-footsteps", "./YipSuGif/sounds/Snow-footsteps.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked7),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked8)
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "smile";
    this.visible = true;
    this.goto(-103, -133);
    yield* this.glide(4, -19, -79);
  }

  *whenGreenFlagClicked2() {
    yield* this.wait(4);
    yield* this.sayAndWait("Hi dad!", 1);
    this.costume = "cookie";
    yield* this.sayAndWait("I baked you some cookies!", 2);
    yield* this.wait(0.2);
    yield* this.thinkAndWait("Did I hear something?", 2);
    yield* this.sayAndWait("Ahhhhhh!", 2);
    this.costume = "mad";
    yield* this.wait(1);
    this.costume = "punch";
  }

  *whenGreenFlagClicked3() {
    yield* this.playSoundUntilDone("Snow-footsteps");
  }

  *whenGreenFlagClicked4() {
    yield* this.wait(15);
    this.costume = "smile";
    yield* this.sayAndWait("Now where did I leave those cookies?", 3);
  }

  *whenGreenFlagClicked5() {
    this.stage.costume = "Winter";
  }

  *whenGreenFlagClicked6() {
    yield* this.wait(19);
    this.visible = false;
    this.stage.costume = "Theater";
  }

  *whenGreenFlagClicked7() {
    yield* this.wait(19);
    this.visible = false;
    this.stage.costume = "Theater";
  }

  *whenGreenFlagClicked8() {
    while (!(this.y > -80)) {
      this.costume = "walking";
      yield* this.wait(0.5);
      this.costume = "smile";
      yield* this.wait(0.5);
      yield;
    }
  }
}
